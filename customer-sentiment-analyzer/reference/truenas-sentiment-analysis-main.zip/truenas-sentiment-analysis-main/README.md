# truenas-sentiment-analysis
AI-powered customer sentiment analysis for TrueNAS support cases
