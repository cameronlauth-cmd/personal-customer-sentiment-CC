"""
Dashboard module for TrueNAS Sentiment Analysis.
Provides interactive Streamlit dashboard for exploring analysis results.
"""
